<?php
/**
 * 爱尔兰语的"怦然心动"
 * 是因为他的出现
 * 
 * @package Coisíní
 * @author 枯木逢春
 * 
 * @link https://wfvp.cc
 */
$this->need('header.php');?>

<?php include('common/index.php'); ?>

<?php include('common/footer.php'); ?>

